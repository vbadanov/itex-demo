// automatically generated, do not modify

package Example

const (
	ColorRed = 1
	ColorGreen = 2
	ColorBlue = 8
)
