# automatically generated, do not modify

# namespace: Example

class Any(object):
    NONE = 0
    Monster = 1
    TestSimpleTableWithEnum = 2

