// automatically generated, do not modify

package MyGame.Example;

public final class Any {
  private Any() { }
  public static final byte NONE = 0;
  public static final byte Monster = 1;
  public static final byte TestSimpleTableWithEnum = 2;

  private static final String[] names = { "NONE", "Monster", "TestSimpleTableWithEnum", };

  public static String name(int e) { return names[e]; }
};

