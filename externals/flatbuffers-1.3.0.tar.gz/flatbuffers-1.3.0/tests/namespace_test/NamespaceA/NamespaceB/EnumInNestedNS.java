// automatically generated, do not modify

package NamespaceA.NamespaceB;

public final class EnumInNestedNS {
  private EnumInNestedNS() { }
  public static final byte A = 0;
  public static final byte B = 1;
  public static final byte C = 2;

  private static final String[] names = { "A", "B", "C", };

  public static String name(int e) { return names[e]; }
};

