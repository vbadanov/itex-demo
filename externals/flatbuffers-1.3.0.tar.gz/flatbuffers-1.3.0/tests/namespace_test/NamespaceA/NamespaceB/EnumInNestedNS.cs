// automatically generated, do not modify

namespace NamespaceA.NamespaceB
{

public enum EnumInNestedNS : sbyte
{
 A = 0,
 B = 1,
 C = 2,
};


}
