// automatically generated, do not modify

package NamespaceB

const (
	EnumInNestedNSA = 0
	EnumInNestedNSB = 1
	EnumInNestedNSC = 2
)
