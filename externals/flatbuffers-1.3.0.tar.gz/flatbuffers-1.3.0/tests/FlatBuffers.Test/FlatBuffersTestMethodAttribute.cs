﻿using System;

namespace FlatBuffers.Test
{
    [AttributeUsage(AttributeTargets.Method)]
    public class FlatBuffersTestMethodAttribute : Attribute
    {
    }
}